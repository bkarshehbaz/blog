-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2017 at 01:56 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`) VALUES
(23, 'videos'),
(25, 'twitter'),
(28, 'programming'),
(29, 'trending'),
(30, 'new category1'),
(31, 'new category 2'),
(32, 'facebook'),
(33, 'comsats');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'images.jpg',
  `comment` text NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `date`, `name`, `username`, `post_id`, `email`, `website`, `image`, `comment`, `status`) VALUES
(14, 1501199746, 'AnyUser', 'user', 51, 'AnyUser', 'AnyUser', 'images.jpg', 'This is comment of anobody :p ', 'approve'),
(15, 1501209757, 'asaass', 'user', 51, 'assa', 'asasa', 'images.jpg', 'Dummy text is here ', 'approve'),
(16, 1501211251, 'dsdasdsad', 'user', 51, 'asdsadsa', 'asdasda', 'images.jpg', 'this is dummy text 3333333333333333', 'approve'),
(17, 1501211736, 'Abubakar Shehbaz', 'bkar', 51, 'asasas', '', 'dp.jpg', 'this is reply on post number 51', 'approve');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `image`) VALUES
(7, 'fb.png'),
(8, 'g+.png'),
(9, 'dp.jpg'),
(10, 'in.png'),
(11, 'slider2.jpeg'),
(12, 'slider2.jpg'),
(13, 'php.jpg'),
(14, 'AAEAAQAAAAAAAAJtAAAAJDc1ODI2NzljLTZlMmQtNGE2Yy1iOTk4LTNiYTVkMGNkOTljOA.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `author_image` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `post_data` text NOT NULL,
  `views` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `date`, `title`, `author`, `author_image`, `image`, `categories`, `tags`, `post_data`, `views`, `status`) VALUES
(49, 1501199220, 'Why bootstrap is used in Web Designing', 'bkar', 'dp.jpg', 'maxresdefault.jpg', 'programming', 'website,bootstrap,tech', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p>Why bootstrap is used in Web Designing&nbsp; Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;Why bootstrap is used in Web Designing&nbsp;</p>\r\n</body>\r\n</html>', 6, 'publish'),
(51, 1501199617, 'Why Php is used in Web Development', 'bkar', 'dp.jpg', 'php.jpg', 'programming', 'website,bootstrap,tech', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p>Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;<br /><br /><br /><img src=\"media/AAEAAQAAAAAAAAJtAAAAJDc1ODI2NzljLTZlMmQtNGE2Yy1iOTk4LTNiYTVkMGNkOTljOA.jpg\" alt=\"AAEAAQAAAAAAAAJtAAAAJDc1ODI2NzljLTZlMmQtNGE2Yy1iOTk4LTNiYTVkMGNkOTljOA.jpg\" width=\"640\" height=\"366\" /><br /><br />Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;Why Php is used in Web Development&nbsp; this is dummy text you can also add a picture here&nbsp;</p>\r\n</body>\r\n</html>', 20, 'publish'),
(53, 1501211626, 'marwan khan\'s first ever post', 'marwan', '12108007_705407202892074_6227241308825599788_n.jpg', 'AAEAAQAAAAAAAAJtAAAAJDc1ODI2NzljLTZlMmQtNGE2Yy1iOTk4LTNiYTVkMGNkOTljOA.jpg', 'facebook', 'tech', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p>marwan khan\'s first ever post marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;marwan khan\'s first ever post&nbsp;</p>\r\n</body>\r\n</html>', 2, 'publish ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `salt` varchar(255) NOT NULL DEFAULT '$2y$10$quickbrownfoxjumpsover'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `date`, `first_name`, `last_name`, `username`, `email`, `image`, `password`, `role`, `details`, `salt`) VALUES
(28, 1501128625, 'Abubakar', 'Shehbaz', 'bkar', 'asasas', 'dp.jpg', '202cb962ac59075b964b07152d234b70', 'admin', 'hi i\'m currently the student of Software engineer in Comsats University And this is my blog .This Blog will  Cover all news about IT. here is edit Section', '$2y$10$quickbrownfoxjumpsover'),
(30, 1501211427, 'marwan', 'khan', 'marwan', 'asaas', '12108007_705407202892074_6227241308825599788_n.jpg', '202cb962ac59075b964b07152d234b70', 'author', 'hy Marwan khan is here ', '$2y$10$quickbrownfoxjumpsover');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
