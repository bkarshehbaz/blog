Copyright &copy; by <a href="#">Abubakar Shehbaz</a> from <?php echo date('Y'); ?>
