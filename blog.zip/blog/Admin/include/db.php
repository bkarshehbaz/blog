<?php
error_reporting(0);
$con = mysqli_connect('localhost','root','','cms');
 ?>
