<?php require_once('include/db.php');
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
  header('Location:login.php');
}
else if(isset($_SESSION['username']) && $_SESSION['role'] == 'author'){
  header('Location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php require_once 'include/top.php'; ?>
  </head>
  <body>
<div class="wrapper">
  <header>
    <?php require_once 'include/header.php'; ?>
  </header><!--Header Ends here -->
<div class="clear">
<div class="container-fluid body-section">
  <div class="row">
    <div class="col-md-3">
      <?php require_once 'include/sidebar.php'; ?>
    </div>
    <div class="col-md-9">
        <h1><i class="fa fa-user-plus"></i> Add User <small>Add new user</small></h1>
        <ol class="breadcrumb">
            <li ><a href="index.html"><i class="fa fa-tachometer"></i> Dashboard</a></li>
            <li class="active"><i class="fa fa-user-plus"></i> Add New User</li>
        </ol>

<?php
if (isset($_POST['submit'])) {
  $date          = time();
  $first_name    = mysqli_real_escape_string($con,$_POST['first-name']);
  $last_name     = mysqli_real_escape_string($con,$_POST['last-name']);
  $username      = mysqli_real_escape_string($con,strtolower($_POST['user-name']));
  $username_trim = preg_replace('/\s+/','',$username);
  $email         = mysqli_real_escape_string($con,strtolower($_POST['email']));
  $password      = mysqli_real_escape_string($con,$_POST['password']);
  $role          = $_POST['role'];
  $image         = $_FILES['image']['name'];
  $image_tmp     = $_FILES['image']['tmp_name'];

  $check_query   = "Select * from users where username = '$username' or email = '$email'";
  $check_run     = mysqli_query($con,$check_query);
  $salt_query    = "Select * from users order by id desc limit 1";
  $salt_run      = mysqli_query($con,$salt_query);
  $salt_row      = mysqli_fetch_array($salt_run);
  $salt          = $salt_row['salt'];
  $password      = md5($password);

  if(empty($first_name) or empty($last_name) or empty($username) or empty($email) or  empty($password) or
  empty($role) or empty($image) or empty($image_tmp) ){
    echo "All (*) fields are Required ";
  }else if($username != $username_trim){
    $error = "Don't Use spaces in username";
  }
  else if(mysqli_num_rows($check_run) > 0){
    $error = "Username or Email Already Exists";
  }else {
    $insert_query  = "INSERT INTO `users` (`id`, `date`, `first_name`, `last_name`, `username`, `email`, `image`, `password`, `role`) VALUES (NULL, '$date', '$first_name', '$last_name', '$username', '$email', '$image', '$password', '$role')";
    if(mysqli_query($con,$insert_query)){
      $msg = "User has been Added ";
      move_uploaded_file($image_tmp,"images/$image");
      $image_check =  "Select * from users order by id desc limit 1";
      $image_run   =  mysqli_query($con,$image_check);
      $image_row   =  mysqli_fetch_array($image_run);
      $check_image =  $image_row['image'];
    }else{
      $error = "User Has not  Updated";
    }
    $first_name    = "";
    $last_name     = "";
    $username      = "";
    $username_trim = "";
    $email         = "";
    $password      = "";
  }

}

 ?>



<div class="row">
  <div class="col-md-8">
    <form class="" action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="first-name">First Name:</label>
        <?php
        if(isset($error)){
          echo "<span class='pull-right' style='color:red;'>$error</span>";
        }else if(isset($msg)){
          echo "<span class='pull-right' style='color:green;'>$msg</span>";
        }
         ?>
        <input type="text" id="first-name" name="first-name"  class="form-control" placeholder="First Name" value="<?php if(isset($first_name)){ echo $first_name;}?>">
      </div>
      <div class="form-group">
        <label for="last-name">Last Name:</label>
        <input type="text" id="last-name" name="last-name"  class="form-control" placeholder="Last Name Name" value="<?php if(isset($last_name)){ echo $last_name;}?>">
      </div>
      <div class="form-group">
        <label for="User-name">User Name:</label>
        <input type="text" name="user-name" id="user-name" class="form-control" placeholder="User Name" value="<?php if(isset($username)){ echo $username;}?>">
      </div>
      <div class="form-group">
        <label for="Email-name">Email Name:</label>
        <input type="text" name="email" id="email" class="form-control" placeholder="Email Address" value="<?php if(isset($email)){ echo $email;}?>">
      </div>
      <div class="form-group">
        <label for="Password-name">Password:</label>
        <input type="password" name="password" id="password" class="form-control" placeholder="Password" value="">
      </div>
      <div class="form-group">
        <label for="role">Role:</label>
        <select  name="role" id="role" class="form-control">
          <option value="author">Author</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="form-group">
        <label for="first-name">Profile Picture:</label>
        <input type="file" name="image" id="image" value="">
      </div>
      <input type="submit" name="submit" value="Add User" class="btn btn-primary">
    </form>
  </div>
  <div class="col-md-4">
<?php
if(isset($check_image)){
  echo "<img src='images/$check_image' width='100%'>";
} ?>
  </div>
</div>
    </div>
  </div>
</div>

<footer class="text-center">
  <?php require_once 'include/footer.php'; ?>
</footer>
</div>











































    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
