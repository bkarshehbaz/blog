<?php

require_once 'include/db.php';
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
  header('Location:login.php');
}

$session_username     = $_SESSION['username'];
$session_author_image = $_SESSION['author_image'];
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
<?php require_once('include/top.php'); ?>
  </head>
  <body>
<div class="wrapper">
  <header>
<?php require_once 'include/header.php'; ?>
  </header><!--Header Ends here -->
<div class="clear">
<div class="container-fluid body-section">
  <div class="row">
    <div class="col-md-3">
<?php require_once 'include/sidebar.php' ?>
    </div>
    <div class="col-md-9">
        <h1><i class="fa fa-plus-square"></i> Add Post <small>Add new post</small></h1>
        <ol class="breadcrumb">
            <li ><a class="index.php"><i class="fa fa-tachometer"></i></a> Dashboard</li>
            <li class="active"><i class="fa fa-plus-square"></i> Add post</li>
        </ol>
        <?php
        if(isset($_POST['submit'])){
          $date        = time();
          $title       = mysqli_real_escape_string($con,$_POST['title']);
          $post_data   = mysqli_real_escape_string($con,$_POST['post-data']);
          $categories  = $_POST['categories'];
          $tags        = mysqli_real_escape_string($con,$_POST['tags']);
          $status      = $_POST['status'];
          $image       = $_FILES['image']['name'];
          $tmp_name    = $_FILES['image']['tmp_name'];
          if(empty($title) or empty($post_data) or empty($tags) or empty($image)){
            $error = "All (*) Fields Are Required ";
          }else {
            $insert_query = "INSERT into posts (date,title,author,author_image,image,categories,tags,post_data,views,status)
            values ('$date','$title','$session_username','$session_author_image','$image','$categories','$tags','$post_data','0','$status')";
            if(mysqli_query($con,$insert_query)){
              $msg        = "Post Has Been Added";
              $path       = "images/$image";
              $title      = "";
              $post_data  = "";
              $tags       = "";
              $status     = "";
              $categories = "";
              if(move_uploaded_file($tmp_name,$path)){
                copy($path,"../$path");
              }
            }else {
              $error = "post has not been updated";
            }
          }
        }
         ?>
        <div class="row">
          <div class="col-xs-12">
            <form class="" action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label for="Title">Title</label>
                <?php
                if(isset($msg)){
                  echo "<span class='pull-right 'style='color:green;'>$msg</span>";
                }else if(isset($error)){
                  echo "<span class='pull-right 'style='color:red;'>$error</span>";
                }
                 ?>
                <input type="text" name="title" value="<?php if(isset($title)){echo $title;}?>" placeholder="Type Post Title Here" class="form-control">
              </div>
              <div class="form-group">
                <a href="media.php" class="btn btn-primary">Add Media </a>
              </div>
              <div class="form-group">
                <textarea name="post-data" id="textarea" rows="10"  class="form-control" >
                  <?php if(isset($post_data)){echo $post_data;}?>
                </textarea>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="file">Post Image:*</label>
                    <input type="file" name="image">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="categories">Categories:*</label>
                    <select class="categories form-control" name="categories">

                      <?php


                      $cat_query = "select * from categories order by id desc";
                      $cat_run   = mysqli_query($con,$cat_query);
                      if (mysqli_num_rows($cat_run) > 0) {

                        while($cat_row = mysqli_fetch_array($cat_run)){
                          $cat_name = $cat_row['category'];
                          echo "<option value='".$cat_name."' ".((isset($categories) and $categories == $cat_name)?"selected":"").">".ucfirst($cat_name)."</option>";
                        }
                      } else {
                        echo "<center><h6>No Category</h6></center>";
                      }
                       ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="tags">Tags:*</label>
                    <input type="text" name="tags" value="<?php if(isset($tags)){echo $tags;} ?>" placeholder="Your Tags here " class="form-control">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="status">status:*</label>
                    <select class="categories form-control" name="status" id="status">
                      <option value="publish <?php if(isset($status) and $status=='publish'){echo "selected";}?>">Publish</option>
                      <option value="draft <?php if(isset($status) and $status=='draft'){echo "selected";}?>"">Draft</option>
                    </select>
                  </div>
                </div>
              </div>
              <input type="submit" class="btn btn-primary" name="submit" value="Add Post">
            </form>
          </div>
        </div>
    </div>
  </div>
</div>

<footer class="text-center">
<?php require_once 'include/footer.php'; ?>
</footer>
</div>











































    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script>
    tinymce.init({
selector: "textarea#textarea",
height: 300,
plugins: [
  "advlist autolink link image lists charmap print preview hr anchor pagebreak",
  "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
  "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
],

toolbar1: "newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking template pagebreak restoredraft",
content_css: [
  '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
  '//www.tinymce.com/css/codepen.min.css'],

menubar: false,
toolbar_items_size: 'small',

style_formats: [{
  title: 'Bold text',
  inline: 'b'
}, {
  title: 'Red text',
  inline: 'span',
  styles: {
    color: '#ff0000'
  }
}, {
  title: 'Red header',
  block: 'h1',
  styles: {
    color: '#ff0000'
  }
}, {
  title: 'Example 1',
  inline: 'span',
  classes: 'example1'
}, {
  title: 'Example 2',
  inline: 'span',
  classes: 'example2'
}, {
  title: 'Table styles'
}, {
  title: 'Table row 1',
  selector: 'tr',
  classes: 'tablerow1'
}],

templates: [{
  title: 'Test template 1',
  content: 'Test 1'
}, {
  title: 'Test template 2',
  content: 'Test 2'
}],

<?php
  $media_query = "select * from media order by id desc";
  $media_run   = mysqli_query($con,$media_query);
  if(mysqli_num_rows($media_run)> 0){


?>
image_list: [
  <?php
  while($media_row = mysqli_fetch_array($media_run)){
    $media_name    = $media_row['image'];

   ?>
  {title:'<?php echo $media_name; ?>',value:'media/<?php echo $media_name; ?>'},
  <?php } ?>
]
<?php   } ?>
});
    </script>
  </body>
</html>
