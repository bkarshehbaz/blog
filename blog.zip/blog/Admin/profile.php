<?php
//error_reporting(0);
require_once 'include/db.php';
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
  header('Location:login.php');
}
$session_username = $_SESSION['username'];
$query            = "select * from users where username ='$session_username'";
$run              = mysqli_query($con,$query);
$row              = mysqli_fetch_array($run);
$image                 = $row['image'];
$id                    = $row['id'];
$date                  = getdate($row['date']);
$day                   = $date['mday'];
$month                  = substr($date['month'],0,3);
$year                  = $date['year'];
$first_name            = $row['first_name'];
$last_name             = $row['last_name'];
$username              = $row['username'];
$email                 = $row['email'];
$role                  = $row['role'];
$details               = $row['details'];
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
<?php require_once('include/top.php'); ?>
  </head>
  <body id="profile">
<div class="wrapper">
  <header>
<?php require_once 'include/header.php'; ?>
  </header><!--Header Ends here -->
<div class="clear">
<div class="container-fluid body-section">
  <div class="row">
    <div class="col-md-3">
<?php require_once 'include/sidebar.php' ?>
    </div>
    <div class="col-md-9">
        <h1><i class="fa fa-user"></i> Profile <small>Personal Details</small></h1>
        <ol class="breadcrumb">
            <li class="active"><a href="index.php"><i class="fa fa-tachometer"> Dashboard</i></a></li>
            <li class="active"><i class="fa fa-user"></i> Profile</li>
        </ol>
        <div class="row">
          <div class="col-xs-12">
            <center><img src="images/<?php echo $image;?> " alt="" id="profile-image" width="200px" class="img-circle img-thumbnail"></center><br /><br />
            <a href="edit-profile.php?edit=<?php echo $id; ?>" class="btn btn-primary pull-right">Edit Profile</a>
            <center>
              <h3>Profile Details</h3>
            </center>
            <br />
            <table class="table  table-bordered">
              <tr>
                <td width="20%"><b>User ID:</b></td>
                <td width="30%"><?php echo $id;?></td>
                <td width="20%"><b>Signup Date</b></td>
                <td width="30%"><?php echo "$day $month $year ";?></td>
              </tr>
              <tr>
                <td width="20%"><b>Frist Name:</b></td>
                <td width="30%"><?php echo $first_name;?></td>
                <td width="20%"><b>Last Name</b></td>
                <td width="30%"><?php echo $last_name;?></td>
              </tr>
              <tr>
                <td width="20%"><b>Username:</b></td>
                <td width="30%"><?php echo $username;?></td>
                <td width="20%"><b>Email</b></td>
                <td width="30%"><?php echo $email;?></td>
              </tr>
              <tr>
                <td width="20%"><b>Role:</b></td>
                <td width="30%"><?php echo $role;?></td>
                <td width="20%"><b></b></td>
                <td width="30%"></td>
              </tr>
            </table>
            <div class="row">
              <div class="col-lg-8 col-sm-12">
                <b>Details</b>
                <div class="">
                  <?php echo $details;?>
                </div>
              </div>
            </div><br />
          </div>
        </div>
    </div>
  </div>
</div>

<footer class="text-center">
<?php require_once 'include/footer.php'; ?>
</footer>
</div>











































    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
