<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>BlogToday.com</title>
<!-- this is shown in tab with title  -->
<link rel="icon" type="img/png" href="images/images.png">

<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/mediaQuery.css">
<link rel="stylesheet" href="css/custom.css">
<link href="https://fonts.googleapis.com/css?family=Oswald:300" rel="stylesheet">
<link rel="stylesheet" href="css/animated.css">
