<?php
error_reporting(0);
if(!$con = mysqli_connect('localhost', 'root', '', 'cms'))
  die("Error connecting to database" . mysqli_error());
?>
