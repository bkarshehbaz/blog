<div class="widgets">
  <form action="index.php" method="post">
       <div class="input-group">
           <input type="text" class="form-control" name="search-title" placeholder="Search for...">
           <span class="input-group-btn">
             <input type="submit" name="search" value="Go" class="btn btn-default">
           </span>
       </div><!-- /input-group -->
     </form>
</div><!-- Widgets Close-->
<div class="widgets">
<div class="widgets">
  <div class="popular">
    <h4>Popular Posts</h4>
    <?php
    $p_query="SELECT * FROM posts WHERE status='publish' ORDER BY views Desc limit 5";
    $p_run = mysqli_query($con,$p_query);
    if(mysqli_num_rows($p_run) > 0){
      while ($p_row = mysqli_fetch_array($p_run)) {
        $p_id    = $p_row['id'];
        $p_date  = getdate($p_row['date']);
        $p_day   = $p_date['mday'];
        $p_month = $p_date['month'];
        $p_year  = $p_date['year'];
        $p_title = $p_row['title'];
        $p_image = $p_row['image'];
     ?>
    <hr>
    <div class="row">
      <div class="col-xs-4">
        <a href="post.php?post_id=<?php echo $p_id; ?>"><img src="images/<?php echo $p_image; ?>" alt="image1"></a>
      </div>
      <div class="col-xm-8 details">
        <a href="post.php?post_id=<?php echo $p_title; ?>"><h5><?php echo $p_title; ?></h5></a>
        <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo "$p_day $p_month $p_year"; ?></p>
      </div>
    </div>
    <?php
  }
    }
    else {
      echo "<h3>No Post Available</h3>" ;
    }
     ?>
  </div>
</div><!-- widgets 2 Ends Copy PAste from here -->
<div class="widgets">
  <div class="popular">
    <h4>Resent Posts</h4>
    <?php
    $p_query="SELECT * FROM posts WHERE status='publish' ORDER BY id Desc limit 5";
    $p_run = mysqli_query($con,$p_query);
    if(mysqli_num_rows($p_run) > 0){
      while ($p_row = mysqli_fetch_array($p_run)) {
        $p_id    = $p_row['id'];
        $p_date  = getdate($p_row['date']);
        $p_day   = $p_date['mday'];
        $p_month = $p_date['month'];
        $p_year  = $p_date['year'];
        $p_title = $p_row['title'];
        $p_image = $p_row['image'];

     ?>
    <hr>
    <div class="row">
      <div class="col-xs-4">
        <a href="post.php?post_id=<?php echo $p_id; ?>"><img src="images/<?php echo $p_image; ?>" alt="image1"></a>
      </div>
      <div class="col-xm-8 details">
        <a href="post.php?post_id=<?php echo $p_title; ?>"><h5><?php echo $p_title; ?></h5></a>
        <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo "$p_day $p_month $p_year"; ?></p>
      </div>
    </div>
    <?php
  }
    }
    else {
      echo "<h3>No Post Available</h3>" ;
    }
     ?>
  </div>
</div><!-- widgets 2 Ends Copy PAste from here -->
<div class="widgets">
  <div class="popular">
    <h4>Categories</h4>
    <hr>
    <div class="row">
      <div class="col-xs-6">
          <ul>
            <?php
            $count=0;
            $c_query = "SELECT * FROM categories";
            $c_run = mysqli_query($con,$c_query);
            if(mysqli_num_rows($c_run) > 0){
              while($c_row = mysqli_fetch_array($c_run)){
                $c_id       = $c_row['id'];
                $c_category = $c_row['category'];
                $count = $count + 1;

                if(($count % 2 )==1){
                  echo "<li><a href='index.php?cat=".$c_id."'>".(ucfirst($c_category))."</a></li>";
                }
              }
            }
            else {
              echo "<p>No Category </p>";
            }
             ?>
          </ul>
      </div>
      <div class="col-xs-6">
          <ul>
            <?php
            $c_query = "SELECT * FROM categories";
            $c_run = mysqli_query($con,$c_query);
            if(mysqli_num_rows($c_run) > 0){
              while($c_row = mysqli_fetch_array($c_run)){
                $c_id       = $c_row['id'];
                $c_category = $c_row['category'];
                $count = $count + 1;

                if(($count % 2 )==0){
                  echo "<li><a href='index.php?cat=".$c_id."'>".(ucfirst($c_category))."</a></li>";
                }
              }
            }
            else {
              echo "<p>No Category </p>";
            }
             ?>
          </ul>
      </div>
    </div>
    </div>
  </div>
  <div class="widgets">
    <div class="popular">
      <h4>Social icons</h4>
      <hr>
        <div class="row">
          <div class="col-xs-4">
            <a href="#"><img src="images/fb.png" class="social-icon" alt="facebook"></a>
          </div>
          <div class="col-xs-4">
            <a href="#"><img src="images/twitter.png"  class="social-icon" alt="twitter"></a>
          </div>
          <div class="col-xs-4">
            <a href="#"><img src="images/youtube.png"  class="social-icon" alt="youtube"></a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-4">
            <a href="#"><img src="images/g+.png"  class="social-icon" alt="googleplusplus"></a>
          </div>
          <div class="col-xs-4">
            <a href="#"><img src="images/in.png"  class="social-icon" alt="linkedIn"></a>
          </div>
          <div class="col-xs-4">
            <a href="#"><img src="images/skype.jpg"  class="social-icon" alt="skype"></a>
          </div>
        </div>
    </div>
    </div>
