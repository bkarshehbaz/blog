<nav class="navbar navbar-inverse">
<div class="container">
<!-- Brand and toggle get grouped for better mobile display -->
<div class="navbar-header">
  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </button>
  <a class="navbar-brand" href="index.php">
    <div class="col-xs-3"><img src="images/logo2.png" alt="logo" width="30px"> </div>
    <div class="col-xs-9">  Today</div>
  </a>
</div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

  <ul class="nav navbar-nav navbar-right">
    <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-list-alt" aria-hidden="true"></i> Categories <span class="caret"></span></a>
      <ul class="dropdown-menu">
        <?php
          $query = "select * from categories ORDER BY id desc";
          $run = mysqli_query($con, $query);
          if(mysqli_num_rows($run) >= 1) {
              while($row = mysqli_fetch_array($run)) {
                $category = ucwords($row['category']);
                $id=$row['id'];
                echo "<li><a href='index.php?cat=".$id."'>$category</a></li>";
                //echo '<li><a href="#' . $category_id .'">' . ucwords($category_name) . '</a></li>';
              }
            }
            else {
              echo "<li><a href='#'>No Categories yet</a></li>";
            }
         ?>
      </ul>
    </li>
      <li><a href="contact.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
  </ul>
</div><!-- /.navbar-collapse -->
</div><!-- /.container-fluid -->
</nav><!-- Nav Ends here-->
