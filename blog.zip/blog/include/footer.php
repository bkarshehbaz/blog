  <div class="container">
      Copyright &copy; by <a href="index.html">Abubakar Shehbaz</a>. All Right Resevered from 2016.
   </div>
