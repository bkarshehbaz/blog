<?php
  require_once 'include/db.php';
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
<?php require_once('include/top.php'); ?>
  </head>
  <body>
<?php require_once('include/header.php'); ?>

<div class="jumbotron">
<div class="container">
  <div id="details" class="animated fadeInLeft">
    <h1>Contact <span>Us</span></h1>
    <p>This blog Covers Everthing which is related about IT</p>
  </div>
</div>
<img src="images/top-image.jpg" alt="Below NavBAr">
</div><!--Jumbotron Ends herE -->












<section>
  <div class="container">
    <div class="row">
      <div class="col-md-8">
          <div class="row">
            <div class="col-md-12">
              <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key= AIzaSyDkOXeHbJr139JQVHkh0vy7G0DklqowhV4 '></script><div style='overflow:hidden;height:400px;width:100%;'><div id='gmap_canvas' style='height:400px;width:100%;'></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> <a href='https://acadooghostwriter.com/'>acadooghostwriter.com</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=02e9c7fad5ed1b560921af2a897963acda382e96'></script><script type='text/javascript'>function init_map(){var myOptions = {zoom:12,center:new google.maps.LatLng(32.1617,74.18830000000003),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(32.1617,74.18830000000003)});infowindow = new google.maps.InfoWindow({content:'<strong>House Location</strong><br>Sialkot Road butterenwali 2nd street<br>12345 Gujranwala<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
            </div>
            <div class="col-md-12 contact-form">
              <h2>Conntact Form</h2><hr>
              <form  action="contact.html" method="post" >
                <div class="form-group">
                  <label for="full-name">Full Name*:</label>
                  <input type="text" name="full-name" id="full-name" class="form-control" placeholder="Full Name">
                </div>
                <div class="form-group">
                  <label for="email">Email*:</label>
                  <input type="text" name="full-name"  id="email" class="form-control" placeholder="Email address">
                </div>
                <div class="form-group">
                  <label for="website">Website:</label>
                  <input type="text" name="full-name"  id="website" class="form-control" placeholder="Website">
                </div>
                <div class="form-group">
                  <label for="message">Message:</label>
                  <textarea name="name" id="message" cols="30" rows="10" placeholder="Your Message Should be Here" class="form-control"  rows="8" cols="80"></textarea>
                  <input type="submit" name="submit" value="submit" class="btn btn-primary">
                </div>
              </form>
            </div>
          </div>
      </div><!--Main Col-md-8 Ends hereeee---------------------------------------->




      <div class="col-md-4">
            <?php require_once('include/sidebar.php'); ?>
      </div><!--Colm 4 Ends here Main-->
  </div><!--After jumbotron's row ends here------>
  </div><!--Container below jumbotrons Ends here      -->
</section>




















  <footer>
     <div class="container">
        Copyright &copy; by <a href="index.html">Abubakar Shehbaz</a>. All Right Resevered from 2016.
     </div>

  </footer>








































    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
